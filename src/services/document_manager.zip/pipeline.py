from pathlib import Path

from services.analyzer import Analyzer


class Pipeline:

    def __init__(self):

        self.analyzer = Analyzer()

    # ====================================
    # Procesar documento
    # ====================================

    def procesar(self, archivo: Path):

        resultado = self.analyzer.analizar(archivo)

        return resultado